<?php

namespace Arphp;

include_once __DIR__ .'/../../I18N/Arabic/Standard.php';

class Standard extends \I18N_Arabic_Standard {
    
}
