<?php

namespace Arphp;

include_once __DIR__ .'/../../I18N/Arabic/KeySwap.php';

class KeySwap extends \I18N_Arabic_KeySwap {
    
}
