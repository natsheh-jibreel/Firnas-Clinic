<?php

namespace Arphp;

include_once __DIR__ .'/../../I18N/Arabic/Date.php';

class Date extends \I18N_Arabic_Date {
    
}
