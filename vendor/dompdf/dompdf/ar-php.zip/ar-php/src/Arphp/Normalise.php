<?php

namespace Arphp;

include_once __DIR__ .'/../../I18N/Arabic/Normalise.php';

class Normalise extends \I18N_Arabic_Normalise {
    
}
