<?php

namespace Arphp;

include_once __DIR__ .  '/../../I18N/Arabic/Gender.php';

class Gender extends \I18N_Arabic_Gender {
    
}
